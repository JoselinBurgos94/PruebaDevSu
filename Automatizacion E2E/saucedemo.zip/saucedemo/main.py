import os, logging,  util, random, time

from selenium_utils import SeleniumLayer 
from datetime import datetime

# Definicion de Carpetas
dir_path = os.path.dirname(__file__)
dir_in = os.path.join(dir_path,"input")
dir_out = os.path.join(dir_path,"output") 
dir_log = os.path.join(dir_path,"log")
util.create_folder_env(dir_path)

# Definicion de Variables
today = datetime.now()
today_line=str(today.strftime("%Y%m%d%H%M%S"))
today_format=str(today.strftime("%d/%m/%Y %H:%M:%S"))
today_date = str(today.strftime("%d/%m/%Y"))

# Loggin file 
file_log=os.path.join(dir_log,'main_' + today_line + ".log")
log=util.config_logging(file_log, logging.DEBUG, True)

se = SeleniumLayer(log, dir_in, dir_path, dir_out)


def load_web_page(url):
    log.debug(f'Iniciar Web Page {url}')
    se.iniciar_driver_chrome()
    se.navegar_url_chrome(url)    
    
def autenticar_usuario(user, password):
    log.debug('Inicicar Sesion')
    se.send_key_visible_element_by_id('user-name', user)
    se.send_key_visible_element_by_id('password', password)
    se.take_screenshot(os.path.join(dir_out,f'login_{today_line}.png'))
    se.click_visible_element_by_id('login-button')
    se.take_screenshot(os.path.join(dir_out,f'login_ok_{today_line}.png'))
    

def obtener_listado_elementos(xpath):
    log.debug('Obtener Lista de items')
    item_elements =  se.find_elements_by_xpath(xpath)
    item_names = [item.text for item in item_elements]
    return item_names

def convertir_a_nombre_elemento(list_items):
    return [str(item).lower().replace(' ','-') for item in list_items]

def agregar_carrito():
    log.debug('Agregar al carrito')
    items_list = obtener_listado_elementos(r"//div[@class='inventory_item_name ']")
    random_items = random.sample(items_list, 2)
    list_elements_id = convertir_a_nombre_elemento(random_items)
    for element in list_elements_id:
        log.debug(f'Agregando elemento {element}')
        se.click_visible_element_by_id(f'add-to-cart-{element}')
        log.debug(f'Elemento {element} agregado')
    se.take_screenshot(os.path.join(dir_out,f'agregar_carrito_{today_line}.png'))
    return random_items

def validate_items_added(items):
    log.debug('Validando items')
    cart_items = obtener_listado_elementos(r"//div[@class='inventory_item_name']")
    return (cart_items == items)
    
def visualizar_carrito(items):
    log.debug('Visualizar carrito')
    se.click_visible_element_by_xpath(r"//a[@class='shopping_cart_link']")
    if not validate_items_added:
        raise TypeError("Elementos agregagdos en lista no son correctos")
    se.take_screenshot(os.path.join(dir_out,f'visualizar_carrito_{today_line}.png'))
    log.debug('Items validados correctamente')
    log.debug('Iniciando checkout')
    se.click_visible_element_by_id('checkout')
    se.take_screenshot(os.path.join(dir_out,f'checkout_{today_line}.png'))
    
def completar_formulario_checkout(data):
    log.debug('Completando informacion')    
    se.send_key_visible_element_by_id('first-name', data['firtsname'])
    se.send_key_visible_element_by_id('last-name', data['lastname'])
    se.send_key_visible_element_by_id('postal-code', data['zipcode'])
    log.debug(f'{data} Cargado')
    se.click_visible_element_by_id('continue')
    log.debug(f'Finalizando checkout')
    se.take_screenshot(os.path.join(dir_out,f'completar_formulario_checkout_{today_line}.png'))
    se.click_visible_element_by_id('finish')
    
def finalizar_checkout():
    log.debug(f'Checkout result')
    if not se.check_exists_visible_element_by_id('checkout_complete_container'):
        raise TypeError("Error al completar checkout")
    se.take_screenshot(os.path.join(dir_out,f'finalizar_checkout_{today_line}.png'))

def main():
    user_name = r'standard_user'
    password =r'secret_sauce' 
    data = {
        'firtsname': 'name1',
        'lastname': 'last1',
        'zipcode':'10001'
    }
    load_web_page(r'https://www.saucedemo.com/')    
    autenticar_usuario(user_name, password)
    items_added = agregar_carrito()
    visualizar_carrito(items_added)
    completar_formulario_checkout(data)
    se.quit_driver_chrome()    
    

main()
