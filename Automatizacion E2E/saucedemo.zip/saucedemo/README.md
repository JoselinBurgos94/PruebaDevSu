Proyecto de Automatización con Selenium
=======================================

Resumen
-------
Este proyecto automatiza una serie de interacciones web utilizando Selenium. 
Incluye funcionalidades como la autenticación de usuarios, selección de artículos, 
gestión del carrito y procesos de pago en una plataforma de comercio electrónico.

Estructura del Proyecto
-----------------------
- `main.py`: Este es el script principal que ejecuta el proceso de automatización.
- `selenium_utils.py`: Este módulo proporciona funciones utilitarias para interactuar 
  con la web utilizando Selenium.
- `util.py`: Este módulo de utilidades incluye varias funciones auxiliares para la 
  gestión de logs, manejo de archivos y configuración.

Requisitos
----------
- Python 3.x
- Selenium
- WebDriver Manager para la gestión automática de controladores
- PIL (Pillow) para el procesamiento de imágenes

Configuración
-------------
1. Clona el repositorio.
2. Instala los paquetes de Python necesarios:
    ```
    pip install -r requirements.txt
    ```

3. Asegúrate de tener Chrome instalado, los controladores necesarios serán gestionados 
   automáticamente por `webdriver_manager`.

Estructura de Carpetas
----------------------
El script creará la siguiente estructura de carpetas en el directorio donde se ejecuta el script:

- `input/backup`
- `output/backup`
- `log`

Logs
----
La configuración de los logs se realizará para escribir en un archivo en el directorio `log`. 
El archivo de log se nombrará con la marca de tiempo actual.

Uso
---
### Ejecución del Script de Automatización

Ejecuta el script `main.py` para iniciar el proceso de automatización:




Funciones y Métodos
--------------------
### `main.py`

- **load_web_page(url)**: Carga la URL especificada en un navegador Chrome.
- **autenticar_usuario(user, password)**: Autentica al usuario con las credenciales proporcionadas.
- **obtener_listado_elementos(xpath)**: Recupera una lista de elementos basados en el XPath proporcionado.
- **convertir_a_nombre_elemento(list_items)**: Convierte los nombres de los elementos a un formato adecuado 
  para ser usados como IDs.
- **agregar_carrito()**: Agrega una selección aleatoria de artículos al carrito.
- **validate_items_added(items)**: Valida los artículos en el carrito.
- **visualizar_carrito(items)**: Visualiza el carrito e inicia el proceso de pago.
- **completar_formulario_checkout(data)**: Completa el formulario de pago con los datos proporcionados.
- **finalizar_checkout()**: Finaliza el proceso de pago y valida la finalización.
- **main()**: Función principal que orquesta todo el proceso.

### `selenium_utils.py`

- **SeleniumLayer**: Clase que encapsula las funcionalidades del WebDriver de Selenium.
  - **iniciar_driver_chrome()**: Inicializa el WebDriver de Chrome.
  - **quit_driver_chrome()**: Cierra el WebDriver de Chrome.
  - **navegar_url_chrome(url)**: Navega a la URL especificada.
  - **clear_visible_element_by_id(id)**: Limpia el campo de entrada identificado por ID.
  - **click_visible_element_by_xpath(xpath)**: Hace clic en el elemento identificado por XPath.
  - **send_key_visible_element_by_id(id, data)**: Envía teclas al elemento identificado por ID.
  - **click_visible_element_by_id(id)**: Hace clic en el elemento identificado por ID.
  - **click_located_element_id(id)**: Hace clic en el elemento ubicado por ID.
  - **send_key_located_element_by_id(id, data)**: Envía teclas al elemento ubicado por ID.
  - **select_by_value_located_by_id(id, value)**: Selecciona un valor en un menú desplegable identificado por ID.
  - **check_exists_visible_element_by_id(id)**: Verifica si un elemento es visible por ID.
  - **check_exists_visible_element_by_xpath(xpath)**: Verifica si un elemento es visible por XPath.
  - **find_elements_by_id(id)**: Encuentra elementos por ID.
  - **find_elements_by_xpath(xpath)**: Encuentra elementos por XPath.
  - **take_screenshot(path)**: Toma una captura de pantalla y la guarda en la ruta especificada.

### `util.py`

- **create_folder_env(dir_path)**: Crea las carpetas de trabajo estándar.
- **config_logging(file_log, level, console)**: Configura la gestión de logs.
- **check_if_string_in_file(filename, string_to_search)**: Verifica si una cadena está presente en un archivo.
- **Configuration**: Clase para cargar archivos de configuración.
- **get_now_format(format)**: Devuelve la hora actual formateada como una cadena.
- **replace_string_in_file(filename_in, filename_out, dict_words)**: Reemplaza cadenas en un archivo basado 
  en un diccionario de palabras.
- **iter_all_strings()**: Generador que devuelve combinaciones de letras secuenciales.
